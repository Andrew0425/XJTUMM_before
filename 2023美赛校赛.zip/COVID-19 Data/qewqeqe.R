library(treeio)
library(ggtree)
library(ggplot2)
setwd('C:\\Users\\86189\\Desktop')
tree=read.tree('Newick Export.nwk')
p<- ggtree(tree,layout='circular',size=0.8,col='deepskyblue4',branch.length='none')+
  geom_tiplab()
