import numpy as np
import random as rd
import matplotlib.pyplot

def LD(X, Y):
    m = len(X)
    n = len(Y)
    LD = np.zeros(shape=(m+1, 2))
    for i in range(m+1):
        LD[i, 0] = i
    for j in range(1, n+1):
        LD[0, 1] = j
        for i in range(1, m+1):
            if X[i-1] == Y[j-1]:
                LD[i, 1] = LD[i-1, 0]
            else:
                LD[i, 1] = 1+min(LD[i-1, 0], LD[i-1, 1], LD[i, 0])
        for i in range(m+1):
            LD[i, 0] = LD[i, 1]
    return LD[m, 1]


def GLD(X, Y, k):
    return (2*LD(X, Y))/(k*(len(X)+len(Y))+LD(X, Y))


def RAND(time):  # 随机字符串
    a = ''
    values = ['A', 'T', 'C', 'G']
    for i in range(time):
        a += rd.choice(values)
    return a


def RC(A, times):  # 随机修改times个碱基
    for i in range(times):
        m = rd.randint(1, len(A)-1)
        if A[m] == 'A':
            A = A[:m]+rd.choice(['T', 'C', 'G'])+A[m+1:]
        elif A[m] == 'T':
            A = A[:m]+rd.choice(['A', 'C', 'G'])+A[m+1:]
        elif A[m] == 'C':
            A = A[:m]+rd.choice(['T', 'A', 'G'])+A[m+1:]
        else:
            A = A[:m]+rd.choice(['T', 'C', 'A'])+A[m+1:]
    return A


def RD(A, times):  # 随机删除times个碱基
    for i in range(times):
        m = rd.randint(1, len(A))
        A = A[:m]+A[m+1:]
    return A


def RA(A, times):  # 随机增加times个字符
    for i in range(times):
        m = rd.randint(1, len(A))
        A = A[:m]+rd.choice(['A', 'T', 'C', 'G'])+A[m:]
    return A


X = RAND(2600);
print('>01'+X)
for i in range(39):
    Y = RC(X,100);
    Y = RD(Y,80);
    Y = RA(Y,80);
    print('>'+str(i+2))
    print(Y);


'''
A = [0.03588290840415486, 0.035348837209302326, 0.034830430797433545, 0.03432700993676603, 0.03383793410507569, 0.033362598770851626, 0.0329004329004329, 0.032450896669513236, 0.03201347935973041, 0.03158769742310889, 0.031173092698933553, 0.03076923076923077, 0.030375699440447643, 0.02999210734017364, 0.029618082618862042, 0.029253271747498075, 0.02889733840304182, 0.02854996243425996, 0.028210838901262063, 0.027879677182685254, 0.02755620014503263]
B = []
for i in range(21):
    B.append(1-(abs(A[i]-0.028)/0.028))
print(B)
matplotlib.pyplot.plot(range(130,172,2),B);
matplotlib.pyplot.scatter(range(130,172,2),B);
matplotlib.pyplot.show()
# K = []
# for i in range(1200,3200,200):
#     n = int(i/100)
#     X = RAND(i)
#     Y = RC(X,n);
#     Y = RD(Y,2*n);
#     Y = RA(Y,2*n);

#     K.append(GLD(X,Y,1.6))
# print(K)

# k = [0.029758850692662903, 0.029469980206729713, 0.030011542901115813, 0.030095759233926128, 0.02985993535477913, 0.029942633272701833, 0.030011542901115813, 0.030069847283059073, 0.029036515618125824, 0.028949799815214044]
# mega = [0.03,0.03,0.031,0.031,0.03,0.03,0.031,0.031,0.03,0.03]
# A = [0.99196169,0.982332674,0.968114287,0.940492476,0.995331178,0.965891396,0.968114287,0.939682728,0.967883854,0.964993327]
# matplotlib.pyplot.plot(range(1200,3200,200),A)
# matplotlib.pyplot.show()
# matplotlib.pyplot.plot(range(1200,3200,200),k)
# matplotlib.pyplot.plot(range(1200,3200,200),mega)
# matplotlib.pyplot.show()


ch = [0.025,0.05,0.075,0.1,0.125,0.15,0.175]
AA = [0.838461538,0.947545013,1,0.776712329,0.65754717,0.63994656,0.6375]
matplotlib.pyplot.plot(ch,AA);
matplotlib.pyplot.show();
'''
