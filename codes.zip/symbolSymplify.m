syms x Pix Piy phi L p F
y=Piy/Pix*x;
f=(x*cos(phi)+(y-F)*sin(phi))^2-2*p*(-x*sin(phi)+(y-F)*cos(phi)+p/2);
latex(collect(f,x))